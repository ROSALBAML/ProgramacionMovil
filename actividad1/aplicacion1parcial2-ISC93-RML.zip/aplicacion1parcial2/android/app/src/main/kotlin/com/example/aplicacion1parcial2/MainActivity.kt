package com.example.aplicacion1parcial2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
